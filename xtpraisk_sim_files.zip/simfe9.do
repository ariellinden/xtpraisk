* simfe9.do
clear all
set more off
set seed 20260901

local b0    = 10
local sigma = 1
local reps  = 2000
local alpha = 0.05
local scen  = 3
local rho1  = 0.7
local rho2  =  0.2

local N_list  "15"
local T_list  "10 20 30"
local b1_list "0 0.20"

local g0  = (`sigma'^2)*(1-`rho2') / ///
            ((1+`rho2')*((1-`rho2')^2 - `rho1'^2))
local g1  = `rho1'*`g0'/(1-`rho2')
local L11 = sqrt(`g0')
local L21 = `g1'/`L11'
local L22 = sqrt(max(`g0' - (`g1'^2)/`g0', 1e-12))

postfile sim_fe           ///
    int    scenario       ///
    int    N_panels       ///
    int    T_periods      ///
    double b1_true        ///
    int    method         ///
    double reject         ///
    double coverage       ///
    double pct_bias       ///
    double rmse           ///
    double se_ratio       ///
    using "E:\ArielStuff\xtpraisk_sims\xtpraisk_simfe9.dta", replace

foreach N of numlist `N_list' {
foreach T of numlist `T_list' {

    quietly {
        clear
        set obs `N'
        gen double alpha = rnormal(0,1)
        sum alpha
        replace alpha = alpha - r(mean)
        gen int panid = _n
        save "E:\ArielStuff\xtpraisk_sims\fe9ufx.dta", replace
    }

foreach b1 of numlist `b1_list' {

    di as txt _newline ///
        "simfe9: Scen=3 rho=(0.7, 0.2)" ///
        "  N=`N'  T=`T'  b1=`b1'"

    local sum_b1_pw = 0
    local sum_b1_dk = 0
    local sum_sq_pw = 0
    local sum_sq_dk = 0
    local sum_se_pw = 0
    local sum_se_dk = 0
    local n_rej_pw  = 0
    local n_rej_dk  = 0
    local n_cov_pw  = 0
    local n_cov_dk  = 0
    local n_ok      = 0

    _dots 0, title(Replications) reps(`reps')
    forvalues rep = 1/`reps' {

        quietly {
            clear
            set obs `= `N'*`T''
            gen int panid = ceil(_n/`T')
            gen int t     = mod(_n-1,`T')+1
            merge m:1 panid using "E:\ArielStuff\xtpraisk_sims\fe9ufx.dta", nogenerate keepusing(alpha)
            sort panid t
            gen double x = rnormal(0,1)
            gen double u = .
            by panid: replace u = `L11'*rnormal() if _n==1
            by panid: replace u = `L21'*(u[_n-1]/`L11') + ///
                `L22'*rnormal() if _n==2
            by panid: replace u = `rho1'*u[_n-1] + `rho2'*u[_n-2] ///
                + rnormal(0,`sigma') if _n>=3
            gen double y = `b0' + alpha + `b1'*x + u
            egen double ymean_i = mean(y), by(panid)
            egen double xmean_i = mean(x), by(panid)
            gen double yd = y - ymean_i
            gen double xd = x - xmean_i
            xtset panid t
        }

        capture quietly xtpraisk yd xd, lag(2) nolog
        local rc_pw   = _rc
        local rank_pw = e(rank)
        if `rc_pw' != 0 | `rank_pw' == 0 | `rank_pw' == . {
            _dots `rep' 1
            continue
        }
        local bpw = _b[xd]
        local spw = _se[xd]
        if missing(`bpw') | missing(`spw') {
            _dots `rep' 1
            continue
        }

        capture quietly xtscc yd xd, lag(2)
        if _rc != 0 {
            _dots `rep' 1
            continue
        }
        local bdk = _b[xd]
        local sdk = _se[xd]
        if missing(`bdk') | missing(`sdk') {
            _dots `rep' 1
            continue
        }

        local ppw  = 2*(1-normal(abs(`bpw'/`spw')))
        local lopw = `bpw' - invnormal(0.975)*`spw'
        local hipw = `bpw' + invnormal(0.975)*`spw'
        local df   = `T' - 1
        local pdk  = 2*ttail(`df',abs(`bdk'/`sdk'))
        local lodk = `bdk' - invttail(`df',0.025)*`sdk'
        local hidk = `bdk' + invttail(`df',0.025)*`sdk'

        local sum_b1_pw = `sum_b1_pw' + `bpw'
        local sum_b1_dk = `sum_b1_dk' + `bdk'
        local sum_sq_pw = `sum_sq_pw' + (`bpw'-`b1')^2
        local sum_sq_dk = `sum_sq_dk' + (`bdk'-`b1')^2
        local sum_se_pw = `sum_se_pw' + `spw'
        local sum_se_dk = `sum_se_dk' + `sdk'
        if `ppw' < `alpha'                   local n_rej_pw = `n_rej_pw' + 1
        if `lopw' <= `b1' & `b1' <= `hipw'  local n_cov_pw = `n_cov_pw' + 1
        if `pdk'  < `alpha'                  local n_rej_dk = `n_rej_dk' + 1
        if `lodk' <= `b1' & `b1' <= `hidk'  local n_cov_dk = `n_cov_dk' + 1
        local n_ok = `n_ok' + 1
        _dots `rep' 0

    }   // rep

    local rmse_pw = sqrt(`sum_sq_pw'/`reps')
    local rmse_dk = sqrt(`sum_sq_dk'/`reps')
    local mb1_pw  = `sum_b1_pw'/`reps'
    local mb1_dk  = `sum_b1_dk'/`reps'
    local mse_pw  = `sum_se_pw'/`reps'
    local mse_dk  = `sum_se_dk'/`reps'
    if `b1' != 0 {
        local bias_pw = 100*(`mb1_pw'-`b1')/`b1'
        local bias_dk = 100*(`mb1_dk'-`b1')/`b1'
    }
    else {
        local bias_pw = 100*`mb1_pw'
        local bias_dk = 100*`mb1_dk'
    }

    post sim_fe (`scen') (`N') (`T') (`b1') (1) ///
        (`n_rej_pw'/`n_ok') (`n_cov_pw'/`n_ok') ///
        (`bias_pw') (`rmse_pw') (`mse_pw'/`rmse_pw')
    post sim_fe (`scen') (`N') (`T') (`b1') (2) ///
        (`n_rej_dk'/`n_ok') (`n_cov_dk'/`n_ok') ///
        (`bias_dk') (`rmse_dk') (`mse_dk'/`rmse_dk')

}   // b1
}   // T
}   // N

postclose sim_fe
capture erase "E:\ArielStuff\xtpraisk_sims\fe9ufx.dta"

use "E:\ArielStuff\xtpraisk_sims\xtpraisk_simfe9.dta", clear
label define sc_lbl 1 "Mild positive (0.4,0.2)"  ///
                    2 "Oscillatory (0.5,-0.4)"    ///
                    3 "High persistent (0.7,0.2)", replace
label define me_lbl 1 "xtpraisk"  2 "xtscc", replace
label values scenario sc_lbl
label values method   me_lbl
label var scenario  "AR(2) autocorrelation scenario"
label var N_panels  "Number of panels (N)"
label var T_periods "Number of time periods (T)"
label var b1_true   "True value of b1 (0=null)"
label var method    "Estimator"
label var reject    "Rejection rate"
label var coverage  "95% CI coverage rate"
label var pct_bias  "Percentage bias in b1"
label var rmse      "Root mean squared error of b1"
label var se_ratio  "SE ratio: mean(SE_hat)/SD(b1hat)"
save "E:\ArielStuff\xtpraisk_sims\xtpraisk_simfe9.dta", replace
di as txt _newline "simfe9 complete."