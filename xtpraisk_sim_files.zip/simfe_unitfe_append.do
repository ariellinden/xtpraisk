* simfe_unitfe_append.do
clear all
set more off

local path "E:\ArielStuff\xtpraisk_sims"


use "`path'\xtpraisk_simfe1.dta", clear
forvalues i = 2/12 {
    append using "`path'\xtpraisk_simfe`i'.dta"
}

label define sc_lbl 1 "Mild positive (0.4,0.2)"   ///
                    2 "Oscillatory (0.5,-0.4)"     ///
                    3 "High persistent (0.7,0.2)", replace
label define me_lbl 1 "xtpraisk"  2 "xtscc", replace
label values scenario sc_lbl
label values method   me_lbl

label var scenario  "AR(2) autocorrelation scenario"
label var N_panels  "Number of panels (N)"
label var T_periods "Number of time periods (T)"
label var b1_true   "True value of b1 (0=null)"
label var method    "Estimator"
label var reject    "Rejection rate"
label var coverage  "95% CI coverage rate"
label var pct_bias  "Percentage bias in b1"
label var rmse      "Root mean squared error of b1"
label var se_ratio  "SE ratio: mean(SE_hat)/SD(b1hat)"

di as txt _newline "Combined dataset: `= _N' observations"
di as txt "Expected: 3 scen x 3 N x 6 T x 2 b1 x 2 methods = 216 rows"
tab scenario method

save "`path'\xtpraisk_simfe_all.dta", replace


gen str15 scen_meth = ""
replace scen_meth = "MildPos_PW"   if scenario==1 & method==1
replace scen_meth = "MildPos_DK"   if scenario==1 & method==2
replace scen_meth = "Oscill_PW"    if scenario==2 & method==1
replace scen_meth = "Oscill_DK"    if scenario==2 & method==2
replace scen_meth = "HiPers_PW"    if scenario==3 & method==1
replace scen_meth = "HiPers_DK"    if scenario==3 & method==2

foreach nv of numlist 10 15 20 {

    di as txt _newline(2) "========================================"
    di as txt "Unit fixed effects  --  N = `nv'"
    di as txt "========================================"

    di as txt _newline "Type I error (b1=0, alpha=0.05):"
    tabdisp T_periods scen_meth if N_panels==`nv' & b1_true==0, ///
        cell(reject) format(%6.3f) center

    di as txt _newline "Power (b1=0.20):"
    tabdisp T_periods scen_meth if N_panels==`nv' & b1_true==0.20, ///
        cell(reject) format(%6.3f) center

    di as txt _newline "95% CI coverage (b1=0.20):"
    tabdisp T_periods scen_meth if N_panels==`nv' & b1_true==0.20, ///
        cell(coverage) format(%6.3f) center

    di as txt _newline "Percentage bias (b1=0.20):"
    tabdisp T_periods scen_meth if N_panels==`nv' & b1_true==0.20, ///
        cell(pct_bias) format(%6.2f) center

    di as txt _newline "RMSE (b1=0.20):"
    tabdisp T_periods scen_meth if N_panels==`nv' & b1_true==0.20, ///
        cell(rmse) format(%6.4f) center

    di as txt _newline "SE ratio (b1=0.20):"
    tabdisp T_periods scen_meth if N_panels==`nv' & b1_true==0.20, ///
        cell(se_ratio) format(%6.3f) center
}

di as txt _newline(2) "Done."