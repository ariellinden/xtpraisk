* xtpraisk_sim_ar3.do
clear all
set more off
set seed 20260203

local b0     = 10
local sigma  = 1
local reps   = 2000
local alpha  = 0.05
local burnin = 200

local rho1_s1 =  0.4
        local rho2_s1 =  0.2
        local rho3_s1 =  0.1
local rho1_s2 =  0.7
        local rho2_s2 = -0.3
        local rho3_s2 =  0.15
local rho1_s3 =  0.6
        local rho2_s3 =  0.25
        local rho3_s3 =  0.1

local N_list  "10 15 20"
local T_list  "10 20 30 50 75 100"
local b1_list "0 0.05 0.10 0.20 0.30"


postfile sim_res          ///
    int    scenario       ///
    int    N_panels       ///
    int    T_periods      ///
    double b1_true        ///
    int    method         ///  1=xtpraisk lag(3)  2=xtscc lag(3)
    double reject         ///
    double coverage       ///
    double pct_bias       ///
    double rmse           ///
    double se_ratio       ///
    using "C:\Users\Ariel\Desktop\ITSA_stuff\xtprais\xtpraisk_sim_ar3.dta", replace

foreach scen of numlist 1/3 {

    local rho1 = `rho1_s`scen''
    local rho2 = `rho2_s`scen''
    local rho3 = `rho3_s`scen''
    local T_tot_buf = `burnin'

    foreach N of numlist `N_list' {
    foreach T of numlist `T_list' {
    foreach b1 of numlist `b1_list' {

        local T_tot = `T' + `burnin'

        di as txt _newline ///
            "AR(3) Primary  Scen=`scen' rho=(`rho1',`rho2',`rho3')" ///
            "  N=`N'  T=`T'  b1=`b1'"

        local sum_b1_pw=0
            local sum_b1_dk=0
        local sum_sq_pw=0
        local sum_sq_dk=0
        local sum_se_pw=0
        local sum_se_dk=0
        local n_rej_pw=0
        local n_rej_dk=0
        local n_cov_pw=0
        local n_cov_dk=0
        local n_ok=0

        _dots 0, title(Replications) reps(`reps')
        forvalues rep = 1/`reps' {
            quietly {
                clear
                set obs `= `N'*`T_tot''
                gen int panid = ceil(_n/`T_tot')
                gen int t_all = mod(_n-1,`T_tot')+1
                sort panid t_all
                gen double u = rnormal(0,`sigma')
                by panid: replace u = `rho1'*u[_n-1] + ///
                    rnormal(0,`sigma') if _n==2
                by panid: replace u = `rho1'*u[_n-1] + `rho2'*u[_n-2] + ///
                    rnormal(0,`sigma') if _n==3
                by panid: replace u = `rho1'*u[_n-1] + `rho2'*u[_n-2] + ///
                    `rho3'*u[_n-3] + rnormal(0,`sigma') if _n>=4
                keep if t_all>`burnin'
                gen int t = t_all - `burnin'
                xtset panid t
                gen double x = rnormal(0,1)
                gen double y = `b0' + `b1'*x + u

            }

            capture quietly xtpraisk y x, lag(3) nolog
            if _rc != 0 {
                _dots `rep' 1
                continue
            }
            local bpw = _b[x]
            local spw = _se[x]
            if missing(`bpw') | missing(`spw') {
                _dots `rep' 1
                continue
            }

            capture quietly xtscc y x, lag(3)
            if _rc != 0 {
                _dots `rep' 1
                continue
            }
            local bdk = _b[x]
            local sdk = _se[x]
            if missing(`bdk') | missing(`sdk') {
                _dots `rep' 1
                continue
            }

            local ppw  = 2*(1-normal(abs(`bpw'/`spw')))
            local lopw = `bpw' - invnormal(0.975)*`spw'
            local hipw = `bpw' + invnormal(0.975)*`spw'
            local df   = `T' - 1
            local pdk  = 2*ttail(`df',abs(`bdk'/`sdk'))
            local lodk = `bdk' - invttail(`df',0.025)*`sdk'
            local hidk = `bdk' + invttail(`df',0.025)*`sdk'

            local sum_b1_pw = `sum_b1_pw' + `bpw'
            local sum_b1_dk = `sum_b1_dk' + `bdk'
            local sum_sq_pw = `sum_sq_pw' + (`bpw'-`b1')^2
            local sum_sq_dk = `sum_sq_dk' + (`bdk'-`b1')^2
            local sum_se_pw = `sum_se_pw' + `spw'
            local sum_se_dk = `sum_se_dk' + `sdk'
            if `ppw'<`alpha'                  local n_rej_pw = `n_rej_pw'+1
            if `lopw'<=`b1'&`b1'<=`hipw'     local n_cov_pw = `n_cov_pw'+1
            if `pdk'<`alpha'                  local n_rej_dk = `n_rej_dk'+1
            if `lodk'<=`b1'&`b1'<=`hidk'     local n_cov_dk = `n_cov_dk'+1
            local n_ok = `n_ok' + 1
            _dots `rep' 0
        }

        local rmse_pw = sqrt(`sum_sq_pw'/`n_ok')
        local rmse_dk = sqrt(`sum_sq_dk'/`n_ok')
        local mse_pw  = `sum_se_pw'/`n_ok'
        local mse_dk  = `sum_se_dk'/`n_ok'
        local mb1_pw  = `sum_b1_pw'/`n_ok'
        local mb1_dk  = `sum_b1_dk'/`n_ok'
        if `b1'!=0 {
            local bias_pw=100*(`mb1_pw'-`b1')/`b1'
            local bias_dk=100*(`mb1_dk'-`b1')/`b1'
        }
        else {
            local bias_pw=100*`mb1_pw'
        local bias_dk=100*`mb1_dk'
        }
        post sim_res (`scen') (`N') (`T') (`b1') (1) ///
            (`n_rej_pw'/`n_ok') (`n_cov_pw'/`n_ok') ///
            (`bias_pw') (`rmse_pw') (`mse_pw'/`rmse_pw')
        post sim_res (`scen') (`N') (`T') (`b1') (2) ///
            (`n_rej_dk'/`n_ok') (`n_cov_dk'/`n_ok') ///
            (`bias_dk') (`rmse_dk') (`mse_dk'/`rmse_dk')
    }
    }
    }
}

postclose sim_res


use "C:\Users\Ariel\Desktop\ITSA_stuff\xtprais\xtpraisk_sim_ar3.dta", clear
label define scen_lbl 1 "Mild positive (0.4, 0.2, 0.1)"   ///
                      2 "Oscillatory (0.7, -0.3, 0.15)"    ///
                      3 "High persistent (0.6, 0.25, 0.1)"
label define meth_lbl 1 "xtpraisk lag(3)" 2 "xtscc lag(3)"
label values scenario scen_lbl
label values method   meth_lbl
label var scenario  "Autocorrelation scenario"
label var N_panels  "Number of panels (N)"
label var T_periods "Number of time periods (T)"
label var b1_true   "True value of b1 (0=null)"
label var method    "Estimator"
label var reject    "Rejection rate (type I error if b1=0; power if b1!=0)"
label var coverage  "95% CI coverage rate"
label var pct_bias  "Percentage bias in b1"
label var rmse      "Root mean squared error of b1"
label var se_ratio  "SE ratio: mean(SE_hat)/SD(b1hat)"
save "C:\Users\Ariel\Desktop\ITSA_stuff\xtprais\xtpraisk_sim_ar3.dta", replace

di as txt _newline "Do-file 3 (AR(3) primary) complete."