* xtpraisk_sim_append.do
clear all
set more off

local path "C:\Users\Ariel\Desktop\ITSA_stuff\xtprais"

use "`path'\xtpraisk_sim_ar1.dta", clear
gen int ar_order = 1
label var ar_order "AR order of DGP"
save "`path'\xtpraisk_sim_ar1_temp.dta", replace

use "`path'\xtpraisk_sim_ar2.dta", clear
gen int ar_order = 2
save "`path'\xtpraisk_sim_ar2_temp.dta", replace

use "`path'\xtpraisk_sim_ar3.dta", clear
gen int ar_order = 3
save "`path'\xtpraisk_sim_ar3_temp.dta", replace

use "`path'\xtpraisk_sim_ar1_temp.dta", clear
append using "`path'\xtpraisk_sim_ar2_temp.dta"
append using "`path'\xtpraisk_sim_ar3_temp.dta"

erase "`path'\xtpraisk_sim_ar1_temp.dta"
erase "`path'\xtpraisk_sim_ar2_temp.dta"
erase "`path'\xtpraisk_sim_ar3_temp.dta"

label define ar_lbl  1 "AR(1)" 2 "AR(2)" 3 "AR(3)"
label values ar_order ar_lbl

gen str40 scenario_str = ""
replace scenario_str = "Mild positive"    if scenario == 1
replace scenario_str = "Oscillatory"      if scenario == 2
replace scenario_str = "High persistent"  if scenario == 3
label var scenario_str "Autocorrelation scenario (text)"

label define meth_lbl 1 "xtpraisk" 2 "xtscc", replace
label values method meth_lbl

order ar_order scenario scenario_str N_panels T_periods b1_true method ///
      reject coverage pct_bias rmse se_ratio

gen byte is_null  = (b1_true == 0)
gen byte is_power = (b1_true != 0)
label var is_null  "1 = null condition (b1=0); use reject for Type I error"
label var is_power "1 = power condition (b1!=0); use reject for power, coverage for CI coverage"

sort ar_order scenario N_panels T_periods b1_true method
save "`path'\xtpraisk_sim_primary.dta", replace

di as txt _newline "Primary dataset appended and saved."
di as txt "Observations: " _N
di as txt "AR orders:    " "1, 2, 3"
di as txt "Scenarios:    " "3 per AR order"
di as txt "N values:     " "10, 15, 20"
di as txt "T values:     " "10, 20, 30, 50, 75, 100"
di as txt "b1 values:    " "0, 0.5, 1.0, 1.5"
di as txt "Methods:      " "1=xtpraisk  2=xtscc"
di as txt _newline "Use is_null==1  for Type I error  (filter on b1_true==0)"
di as txt          "Use is_power==1 for power/coverage (filter on b1_true!=0)"